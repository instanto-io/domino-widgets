/*
 * Copyright © 2019 Dominokit
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.dominokit.rest.shared.request;

import org.dominokit.rest.shared.Response;

/** A wrapper for a response and its associated request metadata. */
public class GenericResponse {

  private final Response response;
  private final RequestMeta requestMeta;

  /**
   * Creates a new instance.
   *
   * @param response the {@link Response}
   * @param requestMeta the {@link RequestMeta}
   */
  public GenericResponse(Response response, RequestMeta requestMeta) {
    this.response = response;
    this.requestMeta = requestMeta;
  }

  /**
   * @return the {@link Response}
   */
  public Response getResponse() {
    return response;
  }

  /**
   * @return the {@link RequestMeta}
   */
  public RequestMeta getRequestMeta() {
    return requestMeta;
  }
}
