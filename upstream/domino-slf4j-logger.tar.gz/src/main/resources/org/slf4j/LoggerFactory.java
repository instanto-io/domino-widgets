/**
 * Copyright (c) 2004-2011 QOS.ch All rights reserved.
 *
 * <p>Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 * and associated documentation files (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * <p>The above copyright notice and this permission notice shall be included in all copies or
 * substantial portions of the Software.
 *
 * <p>THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package org.slf4j;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.HashSet;
import java.util.Set;

import org.dominokit.domino.logger.DefaultDominoLoggingServiceProvider;
import org.dominokit.domino.logger.DominoLoggingAdapter;
import org.slf4j.spi.MDCAdapter;
import org.slf4j.spi.SLF4JServiceProvider;

/**
 * <code>LoggerFactory</code> is essentially a wrapper around an {@link ILoggerFactory} instance
 * bound with <code>LoggerFactory</code> at compile time.
 *
 * <p>
 *
 * <p>Please note that all methods in <code>LoggerFactory</code> are static.
 *
 * @author Ceki G&uuml;lc&uuml;
 * @author Robert Elliot
 */
public class LoggerFactory {
  private LoggerFactory() {}

  // SLF4J 2.x SPI provider used by this super-sourced API
  private static volatile SLF4JServiceProvider PROVIDER = new DefaultDominoLoggingServiceProvider();

  /**
   * Allow applications/libraries to plug an SLF4JServiceProvider in GWT/J2CL environments.
   *
   * @param provider the SLF4J service provider to set
   * @throws IllegalArgumentException if provider is null
   */
  public static void setProvider(SLF4JServiceProvider provider) {
    if (provider == null) throw new IllegalArgumentException("provider == null");
    PROVIDER = provider;
    try {
      provider.initialize();
    } catch (Throwable ignore) {
      // ignore init errors in minimal environment
    }
  }

  /**
   * Returns the currently configured SLF4J service provider.
   *
   * @return the active provider
   */
  public static SLF4JServiceProvider getProvider() {
    return PROVIDER;
  }


  /**
   * Return a logger named according to the name parameter using the bound provider's {@link
   * ILoggerFactory} instance.
   *
   * @param name The name of the logger.
   * @return logger
   */
  public static Logger getLogger(String name) {
    return PROVIDER.getLoggerFactory().getLogger(name);
  }

  /**
   * Return a logger named corresponding to the class passed as parameter, using the bound provider's
   * {@link ILoggerFactory} instance.
   *
   * @param clazz the returned logger will be named after clazz
   * @return logger
   */
  public static Logger getLogger(Class clazz) {
    return getLogger(clazz.getName());
  }
}
