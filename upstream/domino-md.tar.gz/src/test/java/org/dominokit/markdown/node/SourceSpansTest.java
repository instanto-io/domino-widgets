/*
 * Copyright © 2026 Dominokit
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.dominokit.markdown.node;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import org.junit.Test;

public class SourceSpansTest {

  @Test
  public void addAllShouldMergeAdjacentInputRanges() {
    SourceSpans sourceSpans = SourceSpans.empty();

    sourceSpans.addAll(List.of(SourceSpan.of(0, 0, 0, 3)));
    sourceSpans.addAll(List.of(SourceSpan.of(0, 3, 3, 2), SourceSpan.of(1, 0, 6, 1)));

    assertThat(sourceSpans.getSourceSpans())
        .containsExactly(SourceSpan.of(0, 0, 0, 5), SourceSpan.of(1, 0, 6, 1));
  }

  @Test
  public void addAllFromShouldCollectSpansFromNodes() {
    Text first = new Text("first");
    first.setSourceSpans(List.of(SourceSpan.of(0, 0, 0, 5)));
    Text second = new Text("second");
    second.setSourceSpans(List.of(SourceSpan.of(0, 5, 5, 6)));

    SourceSpans sourceSpans = SourceSpans.empty();
    sourceSpans.addAllFrom(List.of(first, second));

    assertThat(sourceSpans.getSourceSpans()).containsExactly(SourceSpan.of(0, 0, 0, 11));
  }
}
