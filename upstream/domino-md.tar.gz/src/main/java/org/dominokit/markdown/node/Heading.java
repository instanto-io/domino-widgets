/*
 * Copyright © 2026 Dominokit
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.dominokit.markdown.node;

/**
 * A heading block.
 *
 * <p>The heading level corresponds to the number of leading {@code #} characters in the source.
 */
public class Heading extends Block {

  private int level;

  /** Dispatch this heading to the visitor. */
  @Override
  public void accept(Visitor visitor) {
    visitor.visit(this);
  }

  /**
   * @return the heading level, from 1 to 6
   */
  public int getLevel() {
    return level;
  }

  /** Set the heading level. */
  public void setLevel(int level) {
    this.level = level;
  }
}
