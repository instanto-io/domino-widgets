/*
 * Copyright © 2019 Dominokit
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.dominokit.jackson.deser.map.key;

import java.util.Date;

/** DateKeyParser interface. */
public interface DateKeyParser<D extends Date> {
  /**
   * parse.
   *
   * @param keyValue a {@link java.lang.String} object.
   * @param deserializer a {@link org.dominokit.jackson.deser.map.key.DateDeserializer} object.
   * @return a D object.
   */
  D parse(String keyValue, DateDeserializer<D> deserializer);
}
