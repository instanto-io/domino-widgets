/*
 * Copyright © 2019 Dominokit
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/*
 * Default ILoggerFactory that returns DominoLoggingAdapter instances.
 */
package org.dominokit.domino.logger;

import org.slf4j.ILoggerFactory;
import org.slf4j.Logger;

/** Default ILoggerFactory that creates {@link DominoLoggingAdapter} instances by name. */
public class DefaultLoggerFactory implements ILoggerFactory {

  /**
   * Returns a logger backed by {@link DominoLoggingAdapter}.
   *
   * @param name the logger name
   * @return a logger instance for the given name
   */
  public Logger getLogger(String name) {
    return new DominoLoggingAdapter(name);
  }
}
