/*
 * Copyright © 2026 Dominokit
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.dominokit.markdown.internal.inline;

import java.util.Set;
import org.dominokit.markdown.node.Code;
import org.dominokit.markdown.node.Text;
import org.dominokit.markdown.parser.SourceLines;
import org.dominokit.markdown.parser.beta.*;
import org.dominokit.markdown.text.Characters;

/**
 * Attempt to parse backticks, returning either a backtick code span or a literal sequence of
 * backticks.
 *
 * <p>The parser follows CommonMark's code-span rules: the opening and closing fence must use the
 * same number of backticks, line breaks inside the span collapse to spaces, and surrounding
 * whitespace is trimmed according to the spec's code-span normalization rule.
 */
public class BackticksInlineParser implements InlineContentParser {

  /**
   * Try to parse a code span or literal backtick run.
   *
   * @param inlineParserState the current inline parser state
   * @return a parsed code node or literal text
   */
  @Override
  public ParsedInline tryParse(InlineParserState inlineParserState) {
    Scanner scanner = inlineParserState.scanner();
    Position start = scanner.position();
    int openingTicks = scanner.matchMultiple('`');
    Position afterOpening = scanner.position();

    while (scanner.find('`') > 0) {
      Position beforeClosing = scanner.position();
      int count = scanner.matchMultiple('`');
      if (count == openingTicks) {
        Code node = new Code();

        String content = scanner.getSource(afterOpening, beforeClosing).getContent();
        content = content.replace('\n', ' ');

        // spec: If the resulting string both begins and ends with a space character, but does not
        // consist
        // entirely of space characters, a single space character is removed from the front and
        // back.
        if (content.length() >= 3
            && content.charAt(0) == ' '
            && content.charAt(content.length() - 1) == ' '
            && Characters.hasNonSpace(content)) {
          content = content.substring(1, content.length() - 1);
        }

        node.setLiteral(content);
        return ParsedInline.of(node, scanner.position());
      }
    }

    // If we got here, we didn't find a matching closing backtick sequence.
    SourceLines source = scanner.getSource(start, afterOpening);
    Text text = new Text(source.getContent());
    return ParsedInline.of(text, afterOpening);
  }

  public static class Factory implements InlineContentParserFactory {
    /**
     * @return the trigger character set for code-span parsing
     */
    @Override
    public Set<Character> getTriggerCharacters() {
      return Set.of('`');
    }

    /**
     * @return a new backtick parser
     */
    @Override
    public InlineContentParser create() {
      return new BackticksInlineParser();
    }
  }
}
