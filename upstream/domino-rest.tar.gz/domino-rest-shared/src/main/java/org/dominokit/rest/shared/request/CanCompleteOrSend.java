/*
 * Copyright © 2019 Dominokit
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.dominokit.rest.shared.request;

/**
 * An interface that allows the caller to set a complete handler on the request
 *
 * @see CanSend
 * @see CompleteHandler
 */
public interface CanCompleteOrSend extends CanSend {
  /**
   * Setting a handler to be called when the request is considered completed either success or
   * failure
   *
   * @param completeHandler the handler to be called
   * @return same instance to support builder pattern
   */
  CanSend onComplete(CompleteHandler completeHandler);

  /**
   * Setting a handler to be called after the request is completed.
   *
   * @param completeHandler the handler to be called
   * @return same instance to support builder pattern
   */
  CanSend onAfterComplete(CompleteHandler completeHandler);
}
